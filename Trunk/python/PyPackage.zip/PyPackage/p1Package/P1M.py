

def P1MF():   print 'P1MF'
