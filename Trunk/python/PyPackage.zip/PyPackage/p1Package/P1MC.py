

class P1MC(): 

  @staticmethod
  def P1MCF():  print 'P1MCF'
