

def PyCommonMF():
  print "PyCommonMF"