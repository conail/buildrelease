
import P2M
from PyPackage import PyCommonM
from PyPackage.p1Package import P1M
from PyPackage.p1Package.P1MC import P1MC


def P2F(): 
  print 'P2F'
  
  
if __name__ == '__main__':
  P2F()
  P2M.P2MF()
  P1M.P1MF()
  P1MC.P1MCF()
  PyCommonM.PyCommonMF()